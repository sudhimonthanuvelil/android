package com.example.android.regulardb;

import android.os.Bundle;
//import android.support.design.widget.FloatingActionButton;
//import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
//import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
//import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

import static com.android.volley.toolbox.Volley.*;

public class Main4Activity extends AppCompatActivity {
    EditText editText,editText1,editText2;
    Button button;
    StringRequest stringRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        editText=findViewById(R.id.editText4);
        editText1=findViewById(R.id.editText5);
        editText2=findViewById(R.id.editText6);
        button=findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deptAdd();

            }
            private void deptAdd() {
                // Toast.makeText(getApplicationContext(),"Sucess",Toast.LENGTH_LONG).show();
                final String URL = "http://192.168.6.141/sudhi/insert.php";


                stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), "keri", Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "no", Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(), "failed" + error, Toast.LENGTH_LONG).show();
                    }
                }) {

                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> Params = new HashMap<>();
                        Params.put("deptname", editText.getText().toString());
                        Params.put("username", editText1.getText().toString());
                        Params.put("password", editText2.getText().toString());
                        return Params;
                    }


                };

                RequestQueue requestQueue= newRequestQueue(Main4Activity.this);
                requestQueue.add(stringRequest);
            }

        });



    }

}
