package com.example.android.volleyapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main3Activity extends AppCompatActivity {
ArrayList<String> list=new ArrayList<String>();
    StringRequest stringRequest;
    ListView l;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        l=(ListView)findViewById(R.id.l1);

        // Toast.makeText(getApplicationContext(),"Sucess",Toast.LENGTH_LONG).show();
        final String URL = "http://192.168.6.169/gracephp/viewall.php";


        stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
               // Toast.makeText(getApplicationContext()," haii",Toast.LENGTH_SHORT).show();

                try{

                    JSONObject json = new JSONObject(response);
                    JSONArray jsonArray=json.getJSONArray("viewdata");

                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject obj=jsonArray.getJSONObject(i);
                            String uname = obj.getString("username");


                         list.add(uname);

                            Toast.makeText(getApplicationContext(), "Sucess \n"+uname, Toast.LENGTH_LONG).show();

                           ArrayAdapter ae=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,list);
                            l.setAdapter(ae);
                        }
                }
                catch(JSONException e){
                    e.printStackTrace();
                    Log.e("name",""+e);
                    Toast.makeText(getApplicationContext(), "Failed"+e, Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "no", Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(), "failed" + error, Toast.LENGTH_LONG).show();
            }
        });

        RequestQueue requestQueue= Volley.newRequestQueue(Main3Activity.this);
        requestQueue.add(stringRequest);
        l.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               Toast.makeText(getApplicationContext(),"msg",Toast.LENGTH_LONG).show();
               Intent in=new Intent(Main3Activity.this,Main4Activity.class);
               String name= (String) parent.getItemAtPosition(position);
              //  Toast.makeText(getApplicationContext(),"msg"+parent.getItemAtPosition(position),Toast.LENGTH_LONG).show();

                in.putExtra("value",name);
                startActivity(in);
            }
        });
    }
}
